//
//  ViewController.swift
//  project2
//
//  Created by admin on 2/3/20.
//  Copyright © 2020 admin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var QuestionLabel: UILabel!
    
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    
    var countries = [String]()
    var score = 0
    var correctAnswer = 0
    
    @IBAction func Exit(_ sender: UIBarButtonItem) {
        let alt = UIAlertController(title: "FLAG APPLICATION", message: "Do you want Exit from this App ?", preferredStyle: .alert)
        alt.addAction(UIAlertAction(title: "Yes", style: .destructive, handler: {(_) in exit(0)}))
        alt.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        
        present(alt, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        countries += ["estonia","france","germany","ireland","italy","monaco","nigeria","poland","russia","spain","uk","us"]
        
        button1.layer.borderWidth = 1
        button2.layer.borderWidth = 1
        button3.layer.borderWidth = 1
        
         button1.layer.borderColor = UIColor.lightGray.cgColor
         button2.layer.borderColor = UIColor.lightGray.cgColor
         button3.layer.borderColor = UIColor.lightGray.cgColor
            
        askQuestion()
    }
    func askQuestion(action: UIAlertAction! = nil){
        title = "Total Score " + String(score)
        countries.shuffle()
        correctAnswer = Int.random(in: 0...2)
        button1.setImage(UIImage(named: countries[0]), for: .normal)
        button2.setImage(UIImage(named: countries[1]), for: .normal)
        button3.setImage(UIImage(named: countries[2]), for: .normal)
        QuestionLabel.text = "Which is the flag of " + countries[correctAnswer].uppercased()
    }
    
    @IBAction func buttonTapped(_ sender: UIButton) {
        if sender.tag == correctAnswer {
            print("correct")
            score += 1
            title = "Correct"
        }
        else {
            print("worng")
            score -= 1
            title = "Wrong"
        }
        let alt = UIAlertController(title: title! + " Answer", message: "Do you want continue ?", preferredStyle: .alert)
        alt.addAction(UIAlertAction(title: "continue", style: .default, handler: askQuestion))
        alt.addAction(UIAlertAction(title: "cancel", style: .cancel, handler: nil))
        
        present(alt, animated: true)
        
        
    }
    


}

